
## 下载(Download)：
稳定版(Stable)：  
https://github.com/XX-net/XX-Net/releases/download/3.13.1/XX-Net-3.13.1.7z


测试版(Test)：  
https://github.com/XX-net/XX-Net/releases/download/3.13.1/XX-Net-3.13.1.7z


Android:  
集成fqrouter和XX-Net，推荐：  
https://github.com/XndroidDev/Xndroid/releases

单纯XX-Net，不能自动设置代理（已停止维护）：    
https://github.com/XX-net/xxnet-android/releases/download/3.6.3/XX-Net-3.6.3-debug.apk
